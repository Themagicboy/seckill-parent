package com.bmw.seckill.service;

import com.bmw.seckill.model.Demo;

import java.util.List;

public interface DemoService {
    List<Demo> list();
}
