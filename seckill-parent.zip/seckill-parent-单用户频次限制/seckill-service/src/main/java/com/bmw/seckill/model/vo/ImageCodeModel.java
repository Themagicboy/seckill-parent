package com.bmw.seckill.model.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class ImageCodeModel implements Serializable {

    private String imageId;

    private String imageStr;
}
