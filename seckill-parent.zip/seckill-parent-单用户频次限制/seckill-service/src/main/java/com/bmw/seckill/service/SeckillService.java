package com.bmw.seckill.service;

import com.bmw.seckill.common.base.BaseResponse;
import com.bmw.seckill.model.http.SeckillReq;
import com.bmw.seckill.model.http.SeckillReqV2;
import com.bmw.seckill.model.http.SeckillReqV3;

public interface SeckillService {

    BaseResponse sOrder(SeckillReq req);

    BaseResponse pOrder(SeckillReq req);

    BaseResponse oOrder(SeckillReq req) throws Exception;

    BaseResponse cOrder(SeckillReq req) throws Exception;

    BaseResponse orderV1(SeckillReq req) throws Exception;

    BaseResponse redissonOrder(SeckillReq req);

    BaseResponse createOrder(SeckillReq req);

    BaseResponse<String> getVerifyHash(SeckillReq req);

    BaseResponse orderV2(SeckillReqV2 req) throws Exception;

    BaseResponse orderV3(SeckillReqV3 req) throws Exception;

    BaseResponse orderV4(SeckillReqV2 req) throws Exception;
}
